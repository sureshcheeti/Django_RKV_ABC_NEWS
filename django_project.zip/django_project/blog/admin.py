from django.contrib import admin
from .models import Post, Updates

admin.site.register(Post)
admin.site.register(Updates)
