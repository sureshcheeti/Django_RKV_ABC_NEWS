from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.models import User
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView
)
from .forms import UpdateForm
from .models import Post, Updates
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin

def home(request):
    return render(request, 'blog/home.html')
    
def report(request):
    return render(request, 'blog/reporter.html')    

def contact(request):
    return render(request, 'blog/contact.html')


#class PostListView(ListView):
#    model = Post
#    template_name = 'blog/scroll.html'  # <app>/<model>_<viewtype>.html
#    context_object_name = 'posts'
#    ordering = ['-date_posted']

#class UpdateListView(ListView):
#    model = Updates
#    template_name = 'blog/all_updates.html'  # <app>/<model>_<viewtype>.html
#    context_object_name = 'updates'
#    ordering = ['-date_posted']

def PostListView(request):
    posts = Post.objects.all().order_by('-date_posted')
    updates = Updates.objects.all().order_by('-date_posted')
    return render(request,"blog/scroll.html",{'posts':posts, 'updates':updates})
class UserPostListView(ListView):
    model = Post
    template_name = 'blog/user_posts.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    paginate_by = 5

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return Post.objects.filter(author=user).order_by('-date_posted')


#class PostDetailView(DetailView):
#    model = Post
#    template_name = 'blog/post-detail.html'
def PostDetailView(request,pk):
    posts = Post.objects.filter(id=pk)
    updates = Updates.objects.all().order_by('-date_posted')
    return render(request,"blog/post-detail.html",{'posts':posts, 'updates':updates})


class PostCreateView(SuccessMessageMixin,LoginRequiredMixin, CreateView):
    model = Post
    template_name = 'blog/post_form.html'
    success_url = '/post/new'
    fields = ['title', 'content', 'main_img', 'video']
    success_message = ' successfully posted!!!!'

    def form_valid(self, form):
        form.instance.author = self.request.user
        form.instance.main_img = self.request.FILES['main_img']
        form.instance.video_url = self.request.FILES['video']
        return super().form_valid(form)


class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'content', 'main_img', 'video']

    def form_valid(self, form):
        form.instance.author = self.request.user
        form.instance.main_img = self.request.FILES['main_img']
        form.instance.video_url = self.request.FILES['video']
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    success_url = '/'

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False
def about(request):
    updates = Updates.objects.all()
    return render(request, "blog/about.html", {'title' : 'About','updates':updates})

def UpdateView(request):
    if request.method == "POST":
            form = UpdateForm(request.POST)
            if form.is_valid():
                branch = form.data.get('branch')
                event_type = form.data.get('event_type')
                update = form.data.get('update')
                if branch != "select":
                        t = Updates.objects.create(branch=branch, event_type=event_type, update=update)
                        t.save()
                        messages.success(request, 'Your successfully post the problem')
                        return redirect('/post/update')
                else:
                    messages.warning(request, 'Inavlid credentials')
                    return redirect('/post/update')

    else:
            form = UpdateForm()
    return render(request, "blog/updates.html", {'form': form})



