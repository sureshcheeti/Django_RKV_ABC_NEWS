from django import forms
from .models import Updates


class UpdateForm(forms.ModelForm):
    types = [
        ('select', 'select'),
        ('CSE', 'CSE'),
        ('ECE', 'ECE'),
        ('CIVIL', 'CIVIL'),
        ('MECH', 'MECH'),
        ('MME', 'MME'),
        ('CHEM', 'CHEM'),
        ('others','others')
    ]
    branch = forms.CharField(widget=forms.Select(choices=types))
    class Meta:
        model = Updates
        fields = ['branch','event_type', 'update']

